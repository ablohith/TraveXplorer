	App.controller('presencectrl', function($scope) {
		$scope.apac = [
        {city:'Mumbai',country:'India'},
        {city:'Shanghai',country:'China'},
        {city:'Manila',country:'Philippines'},
        {city:'Kuala Lumpur',country:'Malaysia'},
        {city:'Bangalore',country:'India'},
        {city:'Singapore',country:'Singapore'},
        {city:'Chengdu',country:'China'},
        {city:'Chandigarh',country:'India'},
        {city:'Melbourne',country:'Australia'},
        {city:'Jakarta',country:'Indonesia'}
        ];
		
		$scope.mena = [
        {city:'Dubai',country:'UAE'},
        {city:'Doha',country:'Qatar'},
        {city:'Jeddah',country:'Saudi Arabia'},
        {city:'Beirut',country:'Lebanon'},
        {city:'Amman',country:'Jordan'},
        {city:'Cairo',country:'Egypt'},
        {city:'Kuwait',country:'Kuwait'},
        {city:'Algiers',country:'Algeria'},
        {city:'Erbil',country:'Iraq'},
        {city:'Casablanca',country:'Morocco'}
        ];
		
		$scope.africa = [
        {city:'Nairobi',country:'Kenya'},
        {city:'Dar es Salaam',country:'Tanzania'},
        {city:'Johannesburg',country:'South Africa'},
        {city:'Laos',country:'Nigeria'},
        {city:'Kinshasa',country:'Congo'},
        {city:'Kampala',country:'Uganda'},
        {city:'Cape Town',country:'South Africa'},
        {city:'Windhoek',country:'Namibia'},
        {city:'Addis Ababa',country:'Ethiopia'},
        {city:'Accra',country:'Ghana'}
        ];
		
		$scope.europe = [
        {city:'Barcelona',country:'Spain'},
        {city:'Milano',country:'Italy'},
        {city:'Warsaw',country:'Poland'},
        {city:'Moscow',country:'Russia'},
        {city:'Stockholm',country:'Sweden'},
        {city:'Toulouse',country:'France'},
        {city:'Stuttgart',country:'Germany'},
        {city:'London',country:'United Kingdom'},
        {city:'Amsterdam',country:'The Netherlands'},
        {city:'Antwerp',country:'Belgium'}
        ];
		
		$scope.na = [
        {city:'San Francisco',country:'United States of America'},
        {city:'Mexico City',country:'Mexico'},
        {city:'Managua',country:'Nicaragua'},
        {city:'Toronto',country:'Canada'},
        {city:'Guadalajara',country:'Mexico'},
        {city:'Miami',country:'United States of America'},
        {city:'Nassau',country:'The Bahamas'},
        {city:'Havana',country:'Cuba'},
        {city:'Vancouver',country:'Canada'},
        {city:'Panama City',country:'Panama'}
        ];
		
		$scope.sa = [
        {city:'Montevideo',country:'Uruguay'},
        {city:'Sao Paulo',country:'Brazil'},
        {city:'Medellin',country:'Colombia'},
        {city:'Santiago',country:'Chile'},
        {city:'Cordoba',country:'Argentina'},
        {city:'Rio de Janerio',country:'Brazil'},
        {city:'Quito',country:'Ecuador '},
        {city:'Buenos Aires',country:'Argentina'},
        {city:'Lima',country:'Peru'},
        {city:'Caracas',country:'Venezuela'}
        ];
	});